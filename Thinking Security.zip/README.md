# Thinking Security - Professional Website Protection

Thinking Security is a high-performance security reverse proxy designed to protect your website from DDoS, Botnets, and common Hacking attempts.

## Features
- **Origin Hiding**: Stop hackers from finding your real server IP.
- **Advanced WAF**: Protection against SQLi, XSS, RCE, and Path Traversal.
- **Botnet Mitigation**: JavaScript-based challenge to block automated bots.
- **Dynamic Rate Limiting**: Prevent volumetric DDoS attacks.
- **Anomaly Detection**: Auto-blocks IPs that perform directory brute-forcing (404 scanning).

## Setup
1. Edit `config.yaml` and set `target_url` to your real website URL (e.g., `http://123.45.67.89:8000`).
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start Thinking:
   ```bash
   python main.py
   ```
4. Point your domain DNS to the ShieldProxy server IP.

## Configuration
- `listen_port`: The port ShieldProxy will listen on (default: 8080).
- `sensitivity`: How aggressive the WAF is (1-10).
- `js_challenge_enabled`: Enable/Disable the anti-bot challenge.
